# Garden roles

This is a Mindgarden v1 canonical tree. `sources/` preserves evidence; `knowledge/` stores durable understanding; `synapses/` records typed relationships; and `publishing/` governs disposable projections.

Domains and topics in metadata are authoritative. Folder placement is only an authoring convenience and never defines the taxonomy. Private overlays live at `../.garden.local`, outside this committed tree.
