# Synapse template

`synapses/` holds typed relationships between stable artifact identities, such
as `related`, `supersedes`, or `derived-from`. Relationships are reviewable
records; directory proximity and wiki links do not silently create them.
