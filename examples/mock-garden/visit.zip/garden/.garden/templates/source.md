# Source template

`sources/` holds faithfully captured or deterministically normalized evidence.
A source is not automatically durable knowledge. Preserve its exact origin,
rights, byte hash, capture time, and provenance before drawing conclusions.

Raw captured sources are excluded from publication by default.
