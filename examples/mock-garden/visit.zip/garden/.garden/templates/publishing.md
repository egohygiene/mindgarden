# Publishing template

`publishing/` holds reviewed projection policy and adapter configuration.
Published sites, indexes, graphs, context packs, and agent entrypoints are
disposable views. They never replace canonical sources or knowledge.

Publication is deny-by-default and requires explicit public visibility,
approval, and eligibility.
