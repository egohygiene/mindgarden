# Knowledge template

`knowledge/` holds durable, human-readable understanding. A record's stable
identity, domains, topics, review state, and visibility live in its v1 metadata;
its folder is only an authoring convenience and is never the taxonomy.

Start new agent-authored knowledge as proposed, unreviewed, excluded from
publication, and private unless an explicit garden policy says otherwise.
