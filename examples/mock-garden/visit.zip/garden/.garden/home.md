# Synthetic garden

This map starts empty. Add reviewed durable records under `knowledge/` and connect them with typed records under `synapses/`.
